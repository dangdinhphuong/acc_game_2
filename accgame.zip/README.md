## Validate pass:
  
    ^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_()^#])[A-Za-z\d@$!%*?&_()^#]{10,20}$
## Validate username:

    ^[A-Z0-9_-]{3,16}$
    ----------------------------------
     if(preg_match('/^[a-zA-Z0-9]{5,}$/', $username)) { // for english chars + numbers only
    // valid username, alphanumeric & longer than or equals 5 chars
}
