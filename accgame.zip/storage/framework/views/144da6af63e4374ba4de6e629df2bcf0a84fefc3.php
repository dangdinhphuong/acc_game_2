<?php $__env->startSection('title' , 'Lịch sử rút vật phẩm'); ?>
<?php $__env->startSection('main_content'); ?>
<div class="section__history-retract">
    <h2 class="title">Lịch sử rút vật phẩm</h2>
    <div class="table__box">
        <table class="table">
            <thead>
                <th class="stt">STT</th>
                <th>Tên người dùng</th>
                <th>Số tiền rút</th>
                <th>Thời gian</th>
            </thead>
            <tbody>
                <?php $index = 1; ?>
                <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index++); ?></td>
                    <td><?php echo e($key->username); ?></td>
                    <td class="points"><?php echo e($key->points); ?>đ</td>
                    <td><?=date_format(date_create($key->date),"H:i:s d/m/Y")?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/screen/historyRetract.blade.php ENDPATH**/ ?>