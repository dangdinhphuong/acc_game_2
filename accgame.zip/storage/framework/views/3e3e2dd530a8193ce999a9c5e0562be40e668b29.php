<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table class="table">
        <thead>

        <tbody>
          <tr>
            <th scope="row">Tên tài khoản</th>
            <td><?php echo e($user->realname); ?></td>
          </tr>
          <tr>
            <th scope="row">Số dư</th>
            <td><?php echo e($user->cash); ?> đ</td>
        
          </tr>
          <tr>
            <th scope="row">Số dư kim cương</th>
            <td>0 💎</td>
       
          </tr>
          <tr>
            <th scope="row">Nhóm tài khoản</th>
            <td><?php echo e($user->getTypeStringAttribute()); ?></td>
          
          </tr>
          <tr>
            <th scope="row">Ngày tham gia</th>
            <td><?php echo e($user->created_at); ?></td>
          </tr>
        </tbody>
      </table>
</body>
</html><?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/profile.blade.php ENDPATH**/ ?>