<?php $__env->startSection('title' , 'Lịch sử nạp thẻ'); ?>
<?php $__env->startSection('main_content'); ?>
<div class="section__history-retract">
    <h2 class="title">Lịch sử nạp thẻ</h2>
    <div class="table__box">
        <table class="table">
            <thead>
                <th class="stt">STT</th>
                <th>Nhà mạng</th>
                <th>Mã seri</th>
                <th>Mệnh giá</th>
                <th>Thời gian</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($key->type); ?></td>
                    <td><?php echo e($key->pin); ?></td>
                    <td class="points"><?= number_format($key->amount , 0 ,'.' , '.') ?>đ</td>
                    <td><?=date_format(date_create($key->date),"H:i:s d/m/Y")?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/screen/historyRecharge.blade.php ENDPATH**/ ?>