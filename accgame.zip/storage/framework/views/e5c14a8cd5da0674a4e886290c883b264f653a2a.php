<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
   <form action="<?php echo e(route('registerpost')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="email" name="email" placeholder="Email">
    <input type="text" name="realname" placeholder="realname">
    <input type="text" name="password" placeholder="password">
    <button type="submit" >Send</button>
   </form>
</body>
</html><?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/register.blade.php ENDPATH**/ ?>