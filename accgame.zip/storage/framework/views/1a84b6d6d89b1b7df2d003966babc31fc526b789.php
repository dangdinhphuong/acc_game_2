<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>send email</title>
</head>
<body>
    <a href="<?php echo e(route('active_account',['token'=> $data['token']])); ?>">
        <?php echo e(route('active_account',['token'=> $data['token']])); ?>

    </a>
</body>
</html><?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/email/emailVerification.blade.php ENDPATH**/ ?>