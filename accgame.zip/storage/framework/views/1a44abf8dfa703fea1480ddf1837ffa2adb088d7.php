<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
   <form action="<?php echo e(route('changePasswordPost')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="current_password" placeholder="current password">
    <input type="text" name="password" placeholder="password">
    <input type="text" name="confirm_password" placeholder="confirm password">
    <button type="submit" >Send</button>
   </form>
   <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
   <script>
    $(document).ready(function () {
    const timeout = 1000;  // 900000 ms = 15 minutes
    var idleTimer = null;
    $('*').bind('mousemove click mouseup mousedown keydown keypress keyup submit change mouseenter scroll resize dblclick', function () {
        clearTimeout(idleTimer);

        idleTimer = setTimeout(function () {
            window.location.href = '<?php echo e(route("logout")); ?>'
        }, timeout);
    });
    $("body").trigger("mousemove");
});
   </script>
</body>
</html>
<?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/changePassword.blade.php ENDPATH**/ ?>