<?php $__env->startSection('title', 'Nạp thẻ tự động'); ?>
<?php $__env->startSection('main_content'); ?>
    <!-- <section class="section__user--info">

        <h2 class="title">Thẻ Nạp Gần Nhất</h2>
        <div class="tw-bg-white tw-rounded tw-p-4 md:tw-py-4 md:tw-px-5 tw-w-full tw-mb-4">
            <div style="color: #fff;">
                <h2 class="tw-text-lg tw-font-semibold">Nạp Thẻ Cào</h2>
                <p class="tw-text-xs">
                    Tự động 24/7 - Nhập sai mệnh giá sẽ mất thẻ.
                </p>
            </div>
            <form id="recharge" action="<?php echo e(route('recharge')); ?>"cstyle="color: #fff;" method="POST">
                <?php echo csrf_field(); ?>
                <div class="tw-mb-2">
                    <div id="msgCard" style="padding-bottom: 13px;"></div>
                    <label> Nhà mạng <b>(Ưu tiên Viettel, Vinaphone)</b></label>
                    <div class="tw-grid tw-grid-cols-12 tw-gap-2 tw-text-sm">

                        <select name="type">
                            <option class="tw-font-medium tw-text-red-600" value="Viettel">
                                Viettel
                            </option>
                            <option class="tw-font-medium tw-text-red-600" value="Vinaphone">
                                Vinaphone
                            </option>
                            <option class="tw-font-medium tw-text-red-600" value="Mobifone">
                                Mobifone
                            </option>

                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error error-realname"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="tw-mb-2">
                    <label> Mệnh giá </label>
                    <select name="amount">
                        <option disabled="disabled" value="">Chọn mệnh giá</option>
                        <option class="tw-font-medium tw-text-red-600" value="10000">
                            Thẻ 10,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="20000">
                            Thẻ 20,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="30000">
                            Thẻ 30,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="50000">
                            Thẻ 50,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="100000">
                            Thẻ 100,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="200000">
                            Thẻ 200,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="300000">
                            Thẻ 300,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="500000">
                            Thẻ 500,000đ
                        </option>
                        <option class="tw-font-medium tw-text-red-600" value="1000000">
                            Thẻ 1,000,000đ
                        </option>
                    </select>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error error-realname"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="tw-mb-4"><label> Mã thẻ </label>
                    <input name="code" placeholder="Mã thẻ" value="<?php echo e(old('code')); ?>" />
                </div>
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error error-realname"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="tw-mb-4"><label> Serial thẻ </label>
                    <input name="serial" placeholder="Serial thẻ" value="<?php echo e(old('serial')); ?>" />
                </div>
                <?php $__errorArgs = ['serial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error error-realname"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button  >
                    Nạp Thẻ
                </button>
            </form>
        </div>
        <div style="color: #fff;">
            <div class="relative">
                <p>
                    <span style="color: rgb(220, 38, 38);"><strong>Lưu ý: </strong></span>
                </p>
                <p>
                    <span style="color: rgb(220, 38, 38);"><strong>- Vui lòng nạp đúng mệnh giá, sai mệnh giá sẽ không được
                            cộng tiền vào tài khoản.</strong></span>
                </p>
                <p>
                    <span style="color: rgb(220, 38, 38);"><strong>- Thẻ cào bị treo ĐANG XỬ LÝ quá 10p kể từ lúc nạp thẻ
                            xin vui lòng liên hện page để được hỗ trợ.</strong></span>
                </p>
            </div>
        </div>
    </section> -->
    <section class="section__card--recharge">
              <h2 class="title">Nạp thẻ siêu tốc</h2>
              <div class="section__card--box">
                <form class="form__card" action="<?php echo e(route('recharge')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <input type="text" id="route" value="<?php echo e(route('recharge')); ?>"  hidden>
                  <div class="form__control">
                    <label for="" class="">Nhà mạng:</label>
                    <div class="home__word home__word-one">
                      <p class="home__word--result">Viettel</p>
                      <i class="fa-solid fa-sort-down"></i>
                      <input type="text" id="home__word" value="Viettel" name="type"  hidden />
                    </div>
                    <div class="home__word--list home__word--list-one">
                      <div class="home__word--item select__item-one">Viettel</div>
                      <div class="home__word--item select__item-one">Vinaphone</div>
                      <div class="home__word--item select__item-one">Mobifone</div>
                    </div>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <p style="color: red;font-size: 15px;margin-top: 2%;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form__control">
                    <label for="" class="">Mệnh giá:</label>
                    <div class="home__word home__word-two ">
                      <p  class="home__word--result-two">10.000đ</p>
                      <i class="fa-solid fa-sort-down"></i>
                      <input type="text" id="money" value="10000" name="amount"  hidden />
                    </div>
                    <div class="home__word--list home__word--list-two">
                      <div class="home__word--item select__item-two" id="10000">10.000đ</div>
                      <div class="home__word--item select__item-two" id="20000">20.000đ</div>
                      <div class="home__word--item select__item-two" id="30000">30.000đ</div>
                      <div class="home__word--item  select__item-two" id="50000">50.000đ</div>
                      <div class="home__word--item select__item-two" id="100000">100.000đ</div>
                      <div class="home__word--item select__item-two" id="200000">200.000đ</div>
                      <div class="home__word--item select__item-two" id="300000">300.000đ</div>
                      <div class="home__word--item select__item-two" id="500000">500.000đ</div>
                      <div class="home__word--item select__item-two" id="1000000">1.000.000đ</div>
                    </div>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  <p style="color: red;font-size: 15px;margin-top: 2%;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form__control">
                    <div class="inputbox">
                      <input 
                        id="code"
                        style="z-index: 1"
                        name="code"
                        type="text"
                      />
                      <span>Mã thẻ</span>
                      <i></i>
                    </div>
                    <p class="error error-code"></p>
                  </div>
                  <div class="form__control">
                    <div class="inputbox">
                      <input 
                        id="serial"
                        style="z-index: 1"
                        type="text"
                        name="serial"
                      />
                      <span>Serial thẻ</span>
                      <i></i>
                    </div>
                    <p class="error error-serial"></p>
                  </div>
                  <button type="submit" class="btn__submit-game">Rút ngay</button>
                </form>
                <div class="hide-sp">
                  <img src="https://motgame.vn/wp-content/uploads/2022/06/tai-minecraft-1-16-5-mien-phi-5.jpg" alt="">
                </div>
              </div>
              <ul class="note">
                <li>Lưu ý:</li>
                <li>
                  - Vui lòng nạp đúng mệnh giá, sai mệnh giá sẽ không được
                </li>
                <li>
                  - Vui lòng nạp đúng mệnh giá, sai mệnh giá sẽ không được cộng
                  tiền vào tài khoản. - Thẻ cào bị treo ĐANG XỬ LÝ quá 10p kể từ
                  lúc nạp thẻ xin vui lòng liên hện page để được hỗ trợ.
                </li>
              </ul>
            </section>
            
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/selector.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/screen/cashRecharge.blade.php ENDPATH**/ ?>