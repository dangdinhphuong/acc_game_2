<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" type="image/x-icon"
        src="<?php echo e(asset('image/z3935489327534_4c7085bdda46955300abe4955beefb66-removebg-preview.png')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" />
</head>

<body>
    <div class="container">
        <!-- Phần header -->
        <?php echo $__env->make('page.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content">
            <div class="containerX content__in">
                <!-- Phần sidebar -->
                <?php echo $__env->make('page.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content__main">
                    <?php echo $__env->yieldContent('main_content'); ?>
                </div>
            </div>
        </div>

        <!-- Phần header -->
        <?php echo $__env->make('page.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div id="backTop" onClick="backTop()" class="back-top active">
        <i class="fa-sharp fa-solid fa-caret-up"></i>
    </div>


    <?php echo $__env->yieldContent('script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.js"
        integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
   
    <script src="<?php echo e(asset('js/active-route.js')); ?>"></script>
    <script src="<?php echo e(asset('js/config.js')); ?>"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php if(session('error')): ?>
        <script>
            swal("", " <?php echo session('error'); ?>", "error", {
                button: "OK",
            })
        </script>
    <?php elseif(session('success')): ?>
        <script>
            swal("", " <?php echo session('success'); ?>", "success", {
                button: "OK",
            })
        </script>
    <?php endif; ?>
    <script>
        // autologout.js

        $(document).ready(function() {
            const timeout = 900000; // 900000 ms = 15 minutes
            var idleTimer = null;
            $('*').bind(
                "mousemove click mouseup mousedown keydown keypress keyup submit change mouseenter scroll resize dblclick ", function () {
                clearTimeout(idleTimer);

                idleTimer = setTimeout(function() {
                    window.location = <?php echo e(route('logout')); ?>;
                }, timeout);
            });
            $("body").trigger("mousemove");
        });
    </script>

</body>

</html>
<?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/layouts/master.blade.php ENDPATH**/ ?>