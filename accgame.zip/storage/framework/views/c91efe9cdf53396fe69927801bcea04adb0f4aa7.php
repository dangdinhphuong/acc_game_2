<?php $__env->startSection('title' , 'Nạp thẻ ATM/MOMO'); ?>
<?php $__env->startSection('main_content'); ?>


<section class="section__card--momo">
    <h2 class="title">Nạp thẻ ATM/MOMO</h2>

    <div class="momo__form-box">
        <form class="form__retract"  action="<?php echo e(route('rechargeMomo')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h3 class="form__title">
                Bước 1: <span>Chọn phương thức nạp</span>
            </h3>
            <div class="form__retract-checkbox">
                <label class="label-checkbox">
                    <input checked name="request_type" value="payWithATM" type="radio" />
                    <div class="checkmark"></div>
                </label>
                <p class="value">Nap thẻ ATM/MOMO</p>
            </div>
            <div class="form__retract-checkbox">
                <div class="form__retract-checkbox--price">
                    <label class="label-checkbox">
                        <input name="request_type" value="captureWallet"  type="radio" />
                        <div class="checkmark"></div>
                    </label>
                </div>
                <p class="value">Nap thẻ bằng mã QR MOMO</p>
            </div>
            <h3 class="form__title">
                Bước 2: <span>Nhập số tiền muốn nạp</span>
            </h3>
            <div class="import__id-game">
                <div class="form__control">
                    <div class="inputbox">
                        <input required="required"  name="money" style="z-index: 1" type="text" value="<?php echo e(old('money')); ?>" />
                        <span>Nhập số tiền</span>
                        <i></i>
                    </div>
                    <?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="error" style="color:red;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
            </div>
            <div class="form__control">
                <button class="btn__submit-game">Rút ngay</button>
            </div>
        </form>
        <div class="momo__img hide-sp">
            <img src="https://touchcinema.com/storage/01-2019/unnamed.jpg" alt="">
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/phuong/Desktop/acc_game/resources/views/page/screen/payMomo.blade.php ENDPATH**/ ?>