<footer class="mt-auto">
    <div class="container-fluid mt-4 mb-6 text-muted">
        <div class="row justify-content-between">
            <div class="col">
                © Dashly. 2022 Webinning.
            </div>

            <div class="col-auto">
                v1.0.0
            </div>
        </div> <!-- / .row -->
    </div>
</footer>